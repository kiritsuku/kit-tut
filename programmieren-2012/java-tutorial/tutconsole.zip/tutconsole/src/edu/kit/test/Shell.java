package edu.kit.test;

import java.util.Arrays;
import java.util.List;

import programmieren.MyTerminal;


public class Shell {

  private boolean isRunning;

  private final Database database = new Database();

  public static void main(final String... args) {
    new Shell().run();
  }

  void run() {
    System.out.println("Welcome to Number Collector!");

    isRunning = true;

    while (isRunning) {
      final String input = MyTerminal.askString("> ");
      final List<String> args = Arrays.asList(input.split("\\s+"));
      final String command = args.get(0);

      try {
        final long start = System.nanoTime();
        handleCommand(command, args.subList(1, args.size()));
        System.out.println("time: " + (System.nanoTime()-start)/1e6 + "ms");
      } catch (final IllegalArgumentException e) {
        System.out.println("Error! " + e.getMessage());
      }
    }
  }

  private void handleCommand(final String command, final List<String> args) {
    System.out.println(command + args);
    if (":q".equals(command)) {
      shutdown();
    } else if ("create".equals(command)) {
      createUser(args);
    } else if ("add".equals(command)) {
      addNumbers(args);
    } else if ("contains".equals(command)) {
      containsNumber(args);
    } else {
      System.out.println("command not found: " + command);
    }
  }

  private void containsNumber(final List<String> args) {
    if (args.size() < 2) {
      throw new IllegalArgumentException("Invalid number of arguments! Expected format: contains <name> <number>");
    }
    final boolean contains = database.containsNumber(args.get(0), args.get(1));
    System.out.println(contains);
  }

  private void addNumbers(final List<String> args) {
    if (args.size() < 2) {
      throw new IllegalArgumentException("Invalid number of arguments! Expected format: add <name> <number1> <number2> <numberN>");
    }
    database.addNumbers(args.get(0), args.subList(1, args.size()));
  }

  private void createUser(final List<String> args) {
    if (args.size() != 1) {
      throw new IllegalArgumentException("Invalid number of arguments! Expected format: create <name>");
    }
    database.createUser(args.get(0));
  }

  private void shutdown() {
    isRunning = false;
  }
}
