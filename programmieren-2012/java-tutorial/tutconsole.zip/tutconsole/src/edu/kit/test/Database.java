package edu.kit.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class Database {

  private final List<String> userNames = new ArrayList<String>();

  private final Map<String, Set<Integer>> datasets = new HashMap<String, Set<Integer>>();

  public void createUser(final String name) {
    if (userNames.contains(name)) {
      throw new IllegalArgumentException(String.format("username '%s' already exists!", name));
    }
    userNames.add(name);
    datasets.put(name, new HashSet<Integer>());
  }

  public void addNumbers(final String name, final List<String> numbers) {
    if (!userNames.contains(name)) {
      throw new IllegalArgumentException(String.format("username '%s' doesn't exist!", name));
    }

    for (final String rawNumber : numbers) {
      final Set<Integer> data = datasets.get(name);
      if (rawNumber.contains("-")) {
        final String[] range = rawNumber.split("-");
        if (range.length != 2) {
          throw new IllegalArgumentException("illegal format for range. Expected: <start>-<end>");
        }
        final int start = Integer.valueOf(range[0]);
        final int end = Integer.valueOf(range[1]);
        for (int i = start; i <= end; ++i) {
          data.add(i);
        }
      } else {
        final int number = Integer.parseInt(rawNumber);
        data.add(number);
      }
    }
  }

  public boolean containsNumber(final String name, final String number) {
    final Set<Integer> numbers = datasets.get(name);
    if (numbers == null) {
      throw new IllegalArgumentException(String.format("username '%s' doesn't exist!", name));
    }
    return numbers.contains(Integer.valueOf(number));
  }
}
